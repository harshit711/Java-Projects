import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.scene.control.Alert;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class registerUser extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pw=response.getWriter();
        response.setContentType("text/html"); 
        
        String fname = request.getParameter("fn");
        String mname = request.getParameter("mn");
        String lname = request.getParameter("ln");
        String email = request.getParameter("eid");
        String cnumber = request.getParameter("phn");
        String user = request.getParameter("uid");
        String pswdd =request.getParameter("pswd");
        String ag =request.getParameter("age");
        String skill =request.getParameter("sset");
        
        Connection conn = null;
        PreparedStatement stmt = null;
		try
		{
      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		    conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=harshit;user=harshit.7;password=harshit7");
                    
                    stmt = conn.prepareStatement("INSERT INTO Employee VALUES (?,?,?,?,?,?,?,?,?)");
                    stmt.setString(1,user);
                    stmt.setString(2,pswdd);
                    stmt.setString(3,fname);
                    stmt.setString(4,mname);
                    stmt.setString(5,lname);
                    stmt.setString(6,ag);
                    stmt.setString(7,email);
                    stmt.setString(8,cnumber);
                    stmt.setString(9,skill);
                    stmt.executeUpdate();

    }catch(SQLException se)
		{
			se.printStackTrace();
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			try{
				if(stmt!=null)
					stmt.close();
				}catch(SQLException se2)
				{ }

				try
				{
					if(conn!=null)
						conn.close();
				}catch(SQLException se)
				{
					se.printStackTrace();
				}
		}
                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                rd.include(request, response);
                response.getWriter().print("<html><body><h2><script>alert('Registration Done')</script></h2></body></html>"); 
	}
}



