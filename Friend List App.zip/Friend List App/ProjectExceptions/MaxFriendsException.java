package ProjectExceptions;

public class MaxFriendsException extends Exception{
	public MaxFriendsException(String s){
		super(s);
	}
}