import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdateInfo extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pw=response.getWriter();
        response.setContentType("text/html"); 
        HttpSession session = request.getSession(false);
        String fnamee = request.getParameter("fnn");
        String mnamee = request.getParameter("mnn");
        String lnamee = request.getParameter("lnn");
        String emid = request.getParameter("eidd");
        String phone = request.getParameter("phnn");
        String usrid = request.getParameter("uidd");
        String passwrd = request.getParameter("paswd");
        String useridd = (String)session.getAttribute("userid");
        
        Connection conn = null;
        PreparedStatement stmt = null;
		try
		{
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		    conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=harshit;user=harshit.7;password=harshit7");
                    String sql;
                    sql="UPDATE Employee SET UserName=?,Password=?,FirstName=?,MiddleName=?,LastName=?,EmailID=?,ContactNumber=? WHERE UserName=?";
                            
                    stmt=conn.prepareStatement(sql);
                    
                    stmt.setString(1, usrid);
                    stmt.setString(2, passwrd);
                    stmt.setString(3, fnamee);
                    stmt.setString(4, mnamee);
                    stmt.setString(5, lnamee);
                    stmt.setString(6, emid);
                    stmt.setString(7, phone);
                    stmt.setString(8, useridd);
                    
                    stmt.executeUpdate();
    }catch(SQLException se)
		{
			se.printStackTrace();
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			try{
				if(stmt!=null)
					stmt.close();
				}catch(SQLException se2)
				{ }

				try
				{
					if(conn!=null)
						conn.close();
				}catch(SQLException se)
				{
					se.printStackTrace();
				}
		}
                RequestDispatcher rd = request.getRequestDispatcher("/welcome.jsp");
                rd.include(request, response);
                pw.print("<html><body><script>alert('Records Updated')</script></body></html>");
	}
}