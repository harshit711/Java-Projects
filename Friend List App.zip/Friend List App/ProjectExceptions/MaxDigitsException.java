package ProjectExceptions;

public class MaxDigitsException extends Exception{
	public MaxDigitsException(String s){
		super(s);
	}
}