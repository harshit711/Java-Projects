package MainClass;

import LoginDetails.*;
import OptionsClass.*;
import ProjectExceptions.*;

import java.util.*;
import java.io.*;

public class Main{
	public static void main(String args[]){
		try{
			Login l = new Login();
			Options o = new Options();
			DisplayOptions d = new DisplayOptions();

			System.out.println("---------------------------------------------------------------");
			System.out.println("-------------------------FRIEND'S LIST-------------------------");
			System.out.println("---------------------------------------------------------------");	

			Scanner scn = new Scanner(System.in);
			String uname, pwd;	

			System.out.print("Enter Username:");
			uname = scn.nextLine();
			System.out.print("Enter Password:");
			pwd = scn.nextLine();	

			boolean verified = l.loginMember(uname,pwd);

			if(verified == true){
				System.out.println("\nLogin Successful!\n");
				o.setUser(uname,pwd);
				d.display(o);
			}else{
				System.out.print("\n");
				try{
					throw new NotRegisteredException("Login Failed! You are not a registered user. Please register!");
				}catch(NotRegisteredException e){
					System.out.println(e);
				}

				char cha1 = 'n';
				String runame, rpwd;

				File f = new File("C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\LoginFile\\Credentials.txt");
				FileWriter fw = new FileWriter(f, true);
				BufferedWriter bw = new BufferedWriter(fw);

				System.out.print("\nDo you want to register? ");
				cha1 = scn.next().charAt(0);

				if(cha1=='Y' || cha1=='y'){
					scn.nextLine();
					System.out.print("Enter username:");
					runame = scn.nextLine();
					System.out.print("Enter password:");
					rpwd = scn.nextLine();

					bw.flush();
					bw.newLine();
					bw.write(runame+","+rpwd);

					System.out.println("\nRegisteration Succesfull!");	
					o.setUser(runame,rpwd);
					d.display(o);
				}else{
					System.out.println("\nYou denied to register!");
				}
				bw.close();
			}
		}catch(IOException e){
			System.out.println(e);
		}
	}
}