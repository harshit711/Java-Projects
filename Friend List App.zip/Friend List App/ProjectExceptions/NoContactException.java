package ProjectExceptions;

public class NoContactException extends Exception{
	public NoContactException(String s){
		super(s);
	}
}