import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = "/GetInfo")
public class GetInfo extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
       PrintWriter pw=response.getWriter();
        response.setContentType("text/html");  
        String user = request.getParameter("usr");
        
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs= null;
        try
		{
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                    conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=harshit;user=harshit.7;password=harshit7");
	            stmt=conn.createStatement();
                    String sql;
	            sql="select * from Employee where UserName='"+user+"'";
		    rs = stmt.executeQuery(sql);
                    RequestDispatcher rd = request.getRequestDispatcher("/index.html");
                    rd.include(request, response);
                    pw.println("<br>");
                    pw.println("<table border=1 style='background-color:lightgray'>");
                    pw.println("<tr><th>"+"Employee ID"+"</th>"+"<th>"+"User ID"+"</th>"+"<th>"+"First Name"+"</th>"
                         +"<th>"+"Middle Name"+"</th>"+"<th>"+"Last Name"+"</th>"+"<th>"+"Age"+"</th>"
                             +"<th>"+"Email-ID"+"</th>"+"<th>"+"Contact Number"+"</th>"+"<th>"+"Skill-Set"+"</th>");
                 while(rs.next())
                 {
        pw.println("<tr><td>"+rs.getString("EmpID")+"</td>"+"<td>"+rs.getString("UserName")+"</td>"+"<td>"
                +rs.getString("FirstName")+"</td>"+"<td>"+rs.getString("MiddleName")+
              "</td>"+"<td>"+rs.getString("LastName")+"</td>"+"<td>"+rs.getString("Age")+"</td>"+"<td>"
                +rs.getString("EmailID")+"</td>"+"<td>"+rs.getString("ContactNumber")+"</td>"+"<td>"+rs.getString("SkillSet")+"</td></tr>");
                 }
                 rs.close();
             pw.println("</table>");
      pw.println("<p style='color:lightgray;margin-top:350px;text-align:left'>");
      pw.println("Professionet Consultancy Services &#169;2019");
      pw.println("</p>");
    }catch(SQLException se)
		{
			se.printStackTrace();
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			try{
				if(stmt!=null)
					stmt.close();
				}catch(SQLException se2)
				{ 
                                      se2.printStackTrace();
                                }
				try
				{
					if(conn!=null)
						conn.close();
				}catch(SQLException se)
				{
					se.printStackTrace();
				}
		}
                pw.close();
	}
}