package ProjectExceptions;

public class NotRegisteredException extends Exception{
	public NotRegisteredException(String s){
		super(s);
	}
}