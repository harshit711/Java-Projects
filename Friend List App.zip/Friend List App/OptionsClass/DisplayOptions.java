package OptionsClass;

import java.io.*;
import java.util.*;

import ProjectExceptions.*;

public class DisplayOptions{
	public void display(Options o){
		try{
			Scanner scn = new Scanner(System.in);
			int choice;
			char cha='n';
			System.out.println("\nPress 1 to display all contacts:");
			System.out.println("Press 2 to add a contact:");
			System.out.println("Press 3 to update a contact:");
			System.out.println("Press 4 to delete a contact:");

			do{
				System.out.print("\nEnter choice:");
				choice = scn.nextInt();

				switch(choice){
					case 1: o.displayMembers();
							break;
					case 2: o.addMembers();
							break;
					case 3: o.updateMembers();
							break;
					case 4: o.deleteMembers();
							break;
				}
				System.out.print("\nDo you want to do any more operations? ");
				cha = scn.next().charAt(0);

			}while(cha =='Y' || cha =='y');
		}catch(MaxDigitsException e){
			System.out.println(e);
		}catch(MaxFriendsException e){
			System.out.println(e);
		}catch(IOException e){
			System.out.println(e);
		}catch(NoContactException e){
			System.out.println(e);
		}
	}
}