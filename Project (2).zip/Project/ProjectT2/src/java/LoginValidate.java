import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginValidate extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter pw=response.getWriter();
        response.setContentType("text/html"); 

        String userr = request.getParameter("uname");
        String psw = request.getParameter("pass");
        
        Connection conn = null;
        PreparedStatement stmt = null;
		try
		{
      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		    conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=harshit;user=harshit.7;password=harshit7");
                    String sql;
                    sql="SELECT * FROM Employee WHERE UserName=? and Password=?";
                    stmt=conn.prepareStatement(sql);
                    stmt.setString(1, userr);
                    stmt.setString(2, psw);
                    
                    ResultSet rs=stmt.executeQuery();
        if(rs.next())
        {
            HttpSession session = request.getSession(true);
            session.setAttribute("userid",userr);
            request.setAttribute("user", userr);
            RequestDispatcher rd = request.getRequestDispatcher("/welcome.jsp");
            rd.forward(request, response);
        }else
        {
            RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
            rd.include(request, response);
            pw.print("<html><body><script>alert('Incorrect Username or Password')</script></body></html>");
            }
    }catch(SQLException se)
		{
			se.printStackTrace();
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			try{
				if(stmt!=null)
					stmt.close();
				}catch(SQLException se2)
				{ }

				try
				{
					if(conn!=null)
						conn.close();
				}catch(SQLException se)
				{
					se.printStackTrace();
				}
		}
 
	}
}