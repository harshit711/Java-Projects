package OptionsClass;

import java.io.*;
import java.util.*;

import LoginDetails.*;
import ProjectExceptions.*;

public class Options extends Input{
	public int CheckNoOfFriends(String user_name) throws IOException{
		int count = 0;
		String user = user_name;
		String filepath = "C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\ContactList\\"+user+".txt";

		File f = new File(filepath);
		FileReader fr = new FileReader(f);
		BufferedReader br = new BufferedReader(fr);	

		String sr;

		while((sr = br.readLine())!=null){
			count++;
		}
		br.close();
		return count;	
	}

	public int propertyFriends() throws IOException{
		File f = new File("C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\Properties\\Properties.txt");
		FileReader fr = new FileReader(f);
		BufferedReader br1 = new BufferedReader(fr);

		int max_friends = 0;
		String sr;

		while((sr = br1.readLine())!=null){
			String tokens[] = sr.split("=");
			if(tokens[0].equals("MAX_FRIENDS")){
				max_friends = Integer.parseInt(tokens[1]);
			}			
		}
		br1.close();
		return max_friends;
	}

	public int CheckNoOfDigits(String contact_no){
		int count = 0;

		count = contact_no.length();

		return count;
	}

	public int propertyDigits() throws IOException{
		File f = new File("C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\Properties\\Properties.txt");
		FileReader fr = new FileReader(f);
		BufferedReader brw = new BufferedReader(fr);

		int max_digits = 0;
		String sr;

		while((sr = brw.readLine())!=null){
			String tokens[] = sr.split("=");
			if(tokens[0].equals("MAX_DIGITS")){
				max_digits = Integer.parseInt(tokens[1]);
			}			
		}
		brw.close();
		return max_digits;
	}

	public void displayMembers() throws IOException{
		String user2 = super.username();
		String fpath3 = "C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\ContactList\\"+user2+".txt";

		File f = new File(fpath3);
		FileReader fin = new FileReader(f);
		BufferedReader bin = new BufferedReader(fin);

		String record;

		System.out.println("-----------------------------------------------------------------------------------------------");
		System.out.println("----------------------CONTACT LIST-------------------------------------------------------------");
		System.out.println("-----------------------------------------------------------------------------------------------");

		System.out.print("\nName\t\t\tContact number\t\t\tAddress\t\t\tDate of Birth\n");

		while((record = bin.readLine())!=null){
			StringTokenizer st = new StringTokenizer(record,",");
			while(st.hasMoreTokens()){
				System.out.println();
				System.out.print(st.nextToken()+"\t\t\t"+st.nextToken()+"\t\t\t"+st.nextToken()+"\t\t\t"+st.nextToken());
			}
		}
		bin.close();
	}

	public void addMembers() throws IOException, MaxFriendsException, MaxDigitsException{
		Scanner scn = new Scanner(System.in);

		DisplayOptions d1 = new DisplayOptions();

		int max_friends = propertyFriends();
		int max_digits = propertyDigits();

		String user1; 
		user1 = super.username();
		String fpath4 = "C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\ContactList\\"+user1+".txt";

		File f = new File(fpath4);
		FileWriter fin = new FileWriter(f,true);
		BufferedWriter bin1 = new BufferedWriter(fin);
		
		if(f.exists() == false){
			f.createNewFile();
		}

		int no_of_friends = CheckNoOfFriends(user1);

		if(no_of_friends < max_friends){

			String name, address, contact, dob;
			System.out.print("Enter name: ");
			name = scn.nextLine();

			System.out.print("Enter contact number: ");
			contact = scn.nextLine();

			int no_of_digits = CheckNoOfDigits(contact);

			if(no_of_digits != max_digits){
				try{
					throw new MaxDigitsException("Enter a 10 digit contact number!");
				}catch(MaxDigitsException e){
					System.out.println(e);
				}
				System.out.print("\nEnter contact number: ");
				contact = scn.nextLine();
			}

			System.out.print("Enter Address: ");
			address = scn.nextLine();

			System.out.print("Enter Date of Birth: ");
			dob = scn.nextLine();

			bin1.write(name+","+contact+","+address+","+dob);
			bin1.newLine();

			bin1.close();
			System.out.println("Record Added Successfully!");
		}else{
			try{
				System.out.print("\n");
				throw new MaxFriendsException("Maximum limit to add contacts reached.You cannot add new friends!");
			}catch(MaxFriendsException e){
				System.err.println(e);
			}
			bin1.close();
			d1.display(this);
		}
	}

	public void updateMembers() throws IOException, MaxDigitsException, NoContactException{
		String user3; 
		user3 = super.username();
		String fpath1 = "C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\ContactList\\"+user3+".txt";

		File f = new File(fpath1);
		FileReader fin = new FileReader(f);
		BufferedReader bin2 = new BufferedReader(fin);

		Scanner scn = new Scanner(System.in);

		String record, name;
		String[] arr = new String[4];

		System.out.print("Enter person's name:");
		name = scn.nextLine();

		System.out.print("\n");

		System.out.println("----------------------------------------------------------------------");
		System.out.println("--------------------UPDATE PERSON'S REORD-----------------------------");
		System.out.println("----------------------------------------------------------------------");

		System.out.println("\n");

		while((record = bin2.readLine())!=null){
			StringTokenizer st = new StringTokenizer(record,",");
			for(int i=0;i<4;i++){
				arr[i] = st.nextToken();
			}
			if(name.equalsIgnoreCase(arr[0])){
				System.out.println("\nName\t\tContact number\t\tAddress\t\tDate of Birth");
				System.out.println(arr[0]+"\t\t"+arr[1]+"\t\t"+arr[2]+"\t\t"+arr[3]);
				break;
			}
		}
		if(!name.equalsIgnoreCase(arr[0])){
			try{
				throw new NoContactException("No record found!");
			}catch(NoContactException e){
				System.out.println(e);
			}
			System.out.println("\n");
			bin2.close();
			}else{

			bin2.close();

			File f1 = new File("C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\ContactList\\members1.txt");
			FileWriter fw = new FileWriter(f1);
			BufferedWriter bw = new BufferedWriter(fw);

			File f2 = new File(fpath1);
			FileReader fr = new FileReader(f2);
			BufferedReader br2 = new BufferedReader(fr);

			String contact=arr[1];
			String address=arr[2]; 
			String dob=arr[3]; 

			String record2;
			char choice='N';

			System.out.print("\nDo you want to update Name? ");
			choice = scn.next().charAt(0);
			if(choice == 'y' || choice == 'Y'){
				System.out.print("Enter updated name: ");
				name = scn.next();
			}

			System.out.println("\n");

			System.out.print("Do you want to update Contact Number? ");
			choice = scn.next().charAt(0);
			if(choice == 'y' || choice == 'Y'){
				System.out.print("Enter updated contact number: ");
				contact = scn.next();

				int no_of_digits = CheckNoOfDigits(contact);
				int max_digits = propertyDigits();

				if(no_of_digits != max_digits){
					try{
						throw new MaxDigitsException("Enter a 10 digit contact number!");
					}catch(MaxDigitsException e){
						System.out.println(e);
					}
					System.out.print("\nEnter updated contact number: ");
					contact = scn.next();
				}
			}

			System.out.print("\n");

			System.out.print("Do you want to update Address? ");
			choice = scn.next().charAt(0);
			if(choice == 'y' || choice == 'Y'){
				System.out.print("Enter updated address: ");
				address = scn.next();
			}

			System.out.print("\n");

			System.out.print("Do you want to update Date of Birth? ");
			choice = scn.next().charAt(0);
			if(choice == 'y' || choice == 'Y'){
				System.out.print("Enter updated Date of Birth: ");
				dob = scn.next();
			}

			while((record2 = br2.readLine())!=null){
				if(record2.contains(arr[0])){
				bw.write(name+","+contact+","+address+","+dob);
				}else{
					bw.write(record2);
				}
				bw.flush();
				bw.newLine();
			}
			br2.close();
			bw.close();
			f.delete();
			boolean success = f1.renameTo(f);
			if(success == true){
				System.out.println("Update successful!");
			}
		}
	}

	public void deleteMembers() throws IOException{
		String user4 = super.username();
		String fpath = "C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\ContactList\\"+user4+".txt";

		File f = new File(fpath);
		FileReader fr = new FileReader(f);
		BufferedReader br4 = new BufferedReader(fr);

		String[] arr = new String[4];

		String record;
		String name;

		Scanner scn = new Scanner(System.in);

		System.out.print("Enter name: ");
		name = scn.nextLine();

		System.out.println("----------------------------------------------------------------------");
		System.out.println("--------------------DELETE PERSON'S REORD-----------------------------");
		System.out.println("----------------------------------------------------------------------");

		while((record = br4.readLine())!=null){
			StringTokenizer st = new StringTokenizer(record, ",");
			for(int i = 0;i<4;i++){
				arr[i] = st.nextToken();
			}
			if(name.equalsIgnoreCase(arr[0])){
				System.out.println("\nName\t\tContact number\t\tAddress\t\tDate of Birth");
				System.out.println(arr[0]+"\t\t"+arr[1]+"\t\t"+arr[2]+"\t\t"+arr[3]);
				break;
			}
		}
		if(!name.equalsIgnoreCase(arr[0])){
			try{	
				throw new NoContactException("No record found!");
			}catch(NoContactException e){
				System.out.println(e);
			}
			System.out.println("\n");
			br4.close();
		}
		else{
			br4.close();
			char c='N';

			File f2 = new File(fpath);
			FileReader fr1 = new FileReader(f2);
			BufferedReader br5 = new BufferedReader(fr1);

			File f1 = new File("C:\\Users\\Harshit\\Desktop\\Java Programs\\ProjectTrial\\ContactList\\members2.txt");
			FileWriter fw = new FileWriter(f1);
			BufferedWriter bw1 = new BufferedWriter(fw);

			System.out.print("Are you sure you want to delete this contact? ");
			c = scn.next().charAt(0);

			if(c == 'Y' || c == 'y'){
				String record2;
				String[] arr1 = new String[4];	

				while((record2 = br5.readLine())!=null){
					StringTokenizer st1 = new StringTokenizer(record2, ",");
					for(int i =0;i<4;i++){
						arr1[i] = st1.nextToken();
					}
					if(name.equalsIgnoreCase(arr1[0])){
						continue;
					}
					else{
						bw1.write(arr1[0]+","+arr1[1]+","+arr1[2]+","+arr1[3]);
					}
					bw1.flush();
					bw1.newLine();
				}				
				br5.close();
				bw1.close();
				f.delete();
				boolean success = f1.renameTo(f);
				if(success == true){
					System.out.println("Record deleted successfully!");		
				}
			}else{
				System.out.println("Record not deleted!");
				br5.close();
				bw1.close();
			}
		}
	}
}