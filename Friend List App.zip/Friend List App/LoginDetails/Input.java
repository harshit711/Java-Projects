package LoginDetails;

import java.util.*;
import java.io.*;

public class Input{
	public String uname;
	public String pwd;

	public void setUser(String uname, String pwd){  
		this.uname = uname;
		this.pwd = pwd;
	}
	public String username(){
		return this.uname;
	}
}